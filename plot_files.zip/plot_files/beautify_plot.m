
gcf;

set(gcf,'Color',[1 1 1]);

font_size = 14;

set(findall(gcf,'type','text'),'fontSize',font_size);
set(findall(gcf,'type','axes'),'fontsize',font_size);
 

ax = gca;

nplots = size(ax.Children,2);


set(gca,'yscale','log')
set(gca,'xscale','log')
set(gca,'LineWidth',1.0)

grid on;
box on;

leg = legend;
set(leg,'Interpreter','LaTex',...
      'Location','southwest',...
      'color','white',...
      'fontsize',13);

ylim([1.0e-3,5e0])
xlim([10,500])
%clear figure_property;
figure_property.units = 'inches';
figure_property.format = 'pdf';
figure_property.Preview= 'none';
figure_property.Width= '10'; % Figure width on canvas
figure_property.Height= '10'; % Figure height on canvas
figure_property.Units= 'inches';
figure_property.Color= 'rgb';
figure_property.Background= 'w';
%figure_property.FixedfontSize= '1';
%figure_property.ScaledfontSize= 'auto';
%figure_property.FontMode= 'scaled';
%figure_property.FontSizeMin= '1';
%figure_property.FixedLineWidth= '1';
%figure_property.ScaledLineWidth= 'auto';
%figure_property.LineMode= 'none';
%figure_property.LineWidthMin= '0.1';
%figure_property.FontName= 'Times New Roman';% Might want to change this to something that is available
%figure_property.FontWeight= 'auto';
%figure_property.FontAngle= 'auto';
%figure_property.FontEncoding= 'latin1';
%figure_property.PSLevel= '3';
%figure_property.Renderer= 'painters';
figure_property.Resolution= '600';
%figure_property.LineStyleMap= 'none';
%figure_property.ApplyStyle= '0';
figure_property.Bounds= 'tight';
%figure_property.LockAxes= 'off';
figure_property.LockAxesTicks= 'on';
figure_property.ShowUI= 'off';
%figure_property.SeparateText= 'off';